package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;

public class AdminPage {
    WebDriver driver;

    public AdminPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }  
    
    public void visitAllModules() {
		// TODO Auto-generated method stub	
	}
    // Add elements or methods as needed
}

