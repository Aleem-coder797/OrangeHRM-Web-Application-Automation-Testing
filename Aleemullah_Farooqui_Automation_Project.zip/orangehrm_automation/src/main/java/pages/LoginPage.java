package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
    WebDriver driver;

    @FindBy(name = "username")
	static
    WebElement usernameField;

    @FindBy(name = "password")
	static
    WebElement passwordField;

    @FindBy(css = "button[type='submit']")
	static
    WebElement loginButton;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public static void enterUsername(String username) {
        try {
			usernameField.sendKeys(username);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    public static void enterPassword(String password) {
        passwordField.sendKeys(password);
    }

    public static void clickLoginButton() {
        loginButton.click();
    }

    public static void login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
    }
}


