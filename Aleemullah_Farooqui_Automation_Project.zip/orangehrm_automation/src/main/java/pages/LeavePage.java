package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class LeavePage {
    WebDriver driver;

    public LeavePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

	public void visitAllModules() {
		// TODO Auto-generated method stub
	}
    // Add elements or methods as needed
}
