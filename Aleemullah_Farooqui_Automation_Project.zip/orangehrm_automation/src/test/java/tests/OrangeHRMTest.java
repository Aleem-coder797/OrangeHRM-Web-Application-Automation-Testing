package tests;

import java.time.Duration;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

import pages.LoginPage;

public class OrangeHRMTest {
    WebDriver driver;

    // Module elements
    @FindBy(xpath = "//span[text()='Admin']")
    WebElement adminModule;

    @FindBy(xpath = "//span[text()='PIM']")
    WebElement pimModule;

    @FindBy(xpath = "//span[text()='Leave']")
    WebElement leaveModule;

    @FindBy(xpath = "//span[text()='Time']")
    WebElement timeModule;

    @FindBy(xpath = "//span[text()='Recruitment']")
    WebElement recruitmentModule;

    @FindBy(xpath = "//span[text()='My Info']")
    WebElement myInfoModule;

    @FindBy(xpath = "//span[text()='Performance']")
    WebElement performanceModule;

    @FindBy(xpath = "//span[text()='Dashboard']")
    WebElement dashboardModule;

    @FindBy(xpath = "//span[text()='Directory']")
    WebElement directoryModule;

    @FindBy(xpath = "//span[text()='Claim']")
    WebElement claimModule;

    @FindBy(xpath = "//span[text()='Buzz']")
    WebElement buzzModule;

    // Logout elements
    @FindBy(xpath = "//p[@class='oxd-userdropdown-name']")
    WebElement userDropdown;

    @FindBy(xpath = "//a[text()='Logout']")
    WebElement logoutButton;

    @BeforeMethod
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\lenovo\\eclipse-workspace\\orangehrm_automation\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

        // Initialize page elements in this class
        PageFactory.initElements(driver, this);
    }

    @SuppressWarnings("static-access")
	@Test
    public void testOrangeHRMLoginNavigationLogout() throws InterruptedException {
        try {
            // Login
            LoginPage loginPage = new LoginPage(driver);
            loginPage.login("Admin", "admin123");

            // Visit modules one by one
            visitModule("Admin", adminModule);
            visitModule("PIM", pimModule);
            visitModule("Leave", leaveModule);
            visitModule("Time", timeModule);
            visitModule("Recruitment", recruitmentModule);
            visitModule("My Info", myInfoModule);
            visitModule("Performance", performanceModule);
            visitModule("Dashboard", dashboardModule);
            visitModule("Directory", directoryModule);
            visitModule("Claim", claimModule);
            visitModule("Buzz", buzzModule);

            // Logout
            System.out.println("Clicking user dropdown...");
            waitForClick(userDropdown).click();
            Thread.sleep(1000);
            System.out.println("Clicking logout...");
            waitForClick(logoutButton).click();
            System.out.println("✅ Logged out successfully.");

        } catch (Exception e) {
            System.out.println("❌ Test failed due to: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void visitModule(String name, WebElement element) {
        try {
            System.out.println("🔄 Navigating to: " + name);
            scrollIntoView(element);
            waitForClick(element).click();
            Thread.sleep(1000);
        } catch (Exception e) {
            System.out.println("⚠️ Could not click on " + name + ": " + e.getMessage());
        }
    }

    public WebElement waitForClick(WebElement element) {
        return new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.elementToBeClickable(element));
    }

    public void scrollIntoView(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }

    @AfterMethod
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
